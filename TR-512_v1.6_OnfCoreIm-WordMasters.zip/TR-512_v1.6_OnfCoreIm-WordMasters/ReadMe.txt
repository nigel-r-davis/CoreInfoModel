It is recommended that you start with TR-512.1_v1.2_OnfCoreIm-Overview.pdf as this provides a guide to the structure of the documents and will ease navigation through the documents.

To enable the navigation it is important that the .zip is unzipped as one so that you have the right structure in your environment.